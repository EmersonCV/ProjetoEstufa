﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;  // necessário para ter acesso as portas

namespace ExNivel
{
    public partial class Form1 : Form
    {
        public static class Globals{
            public static int valorNivel;
        }

        public Form1()
        {
            InitializeComponent();
            timer1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1_Tick(null, null);
            timer2_Tick(null, null);
           
            //Rotina para atualizar comboBox com as portas COMs:                                    
            foreach (string comStr in SerialPort.GetPortNames())
            {   //Adiciona todas as COM diponíveis na lista
                cmb_conn.Items.Add(comStr);
            }
            //Seleciona a primeira posição da lista
            if (cmb_conn.Items.Count > 0)
            {
                cmb_conn.SelectedIndex = 0;
            }
        }

        private void btn_conn_Click(object sender, EventArgs e)
        {
            //Verifica se a porta COM do Arduino foi selecionada:
            if (cmb_conn.SelectedIndex < 0)
            {
                MessageBox.Show("Adicionar/Selecionar uma COM!");
                return;
            }

            if (serialPort1.IsOpen == false)
            {   //Se a conexao serial estiver fechada... abre uma conexao com o Arduino:
                try
                {
                    serialPort1.PortName = cmb_conn.Items[cmb_conn.SelectedIndex].ToString();
                    serialPort1.Open();
                    timerLeitura.Enabled = true;
                    cmb_conn.Enabled = false;
                    btn_conn.Text = "Desconectar";
                }
                catch (Exception ex)
                {   //Erro ao conectar com o Arduino:
                    MessageBox.Show(ex.Message);                    
                }
            }
            else
            {   //Se a conexao serial estiver aberta... fecha a conexao com o Arduino:
                try
                {
                    serialPort1.Close();
                    timerLeitura.Enabled = false;
                    btn_ligar.Enabled = true;
                    cmb_conn.Enabled = true;
                    btn_conn.Text = "Conectar";
                }
                catch (Exception ex)
                {   //Erro ao fechar a conexao com Arduino:
                    MessageBox.Show(ex.Message);                   
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {   //Se a conexao serial estiver aberta... fecha a conexao com o Arduino:
            if (serialPort1.IsOpen == true)
                serialPort1.Close();
        }

        private void timerLeitura_Tick(object sender, EventArgs e)
        {   //Envia um comando para o Arduino enviar os dados monitorados...
            if (serialPort1.IsOpen == true)
                serialPort1.Write("W");
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {   //receber valor pela serial...
            string RxStr = serialPort1.ReadLine();  //le o dado disponível na serial                                                           
            RxStr = RxStr.Replace("\r", "");        //retirar codigo de nova linha...            

            string[] valores = RxStr.Split('#');    //divide a string pelo #
            // ligado#snb#sna#motor#b1#b2#b3#nivel

            int ligado = int.Parse(valores[0]);

            Globals.valorNivel = int.Parse(valores[7]);

            if (ligado == 1)
            {
                btn_ligar.Enabled = false;
            }
            else
            {
                btn_ligar.Enabled = true;
            }


            if (valores[1] == "1") // snb
                snb.BackColor = Color.Green;
            else
                snb.BackColor = Color.Black;
            
            if (valores[2] == "1") // sna
                snb.BackColor = Color.Green;
            else
                snb.BackColor = Color.Black;


            if(valores[3] == "1") // motor
                timer_motor.Enabled = false;
            else
                timer_motor.Enabled = true;

            if (valores[4] == "1") // bomba 01
            { 
                b1_01.BackColor = Color.Blue;
                b1_02.BackColor = Color.Blue;
                //b1_img
            }
            else
            {
                b1_01.BackColor = Color.Gray;
                b1_02.BackColor = Color.Gray;
                //b1_img
            }

            if (valores[5] == "1") // bomba 02
            { 
                b2_01.BackColor = Color.Blue;
                b2_02.BackColor = Color.Blue;
                //b2_img
            }
            else
            {
                b2_01.BackColor = Color.Gray;
                b2_02.BackColor = Color.Gray;
                //b2_img
            }

            if (valores[6] == "1") // bomba 02
            {
                b3_01.BackColor = Color.Blue;
                b3_02.BackColor = Color.Blue;
                //b3_img
            }
            else
            {
                b3_01.BackColor = Color.Gray;
                b3_02.BackColor = Color.Gray;
                //b3_img
            }

            
                
     
            //converte o valor recebido do Arduino... mostra num label...
            //lbValor1.Text = pegaTensao(valores[0], 0);
            //lbValor2.Text = pegaTensao(valores[1], 1);

            //if (valores[2] == "1")
            //    BT1.BackColor = Color.Lime;
            //else
            //    BT1.BackColor = Color.Yellow;

            //if (valores[3] == "1")
            //    BT2.BackColor = Color.Lime;
            //else
            //    BT2.BackColor = Color.Yellow;
        }

        //private string pegaTensao(string valor, int Ang)
        //{
        //    double tensao = Convert.ToDouble(valor) * 5.0 / 1023.0;
        //    return "Tensão A" + Ang + " = " + tensao.ToString("#0.000") + " V";
        //}  

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Rotina do temporizador timer1... roda a cada 100ms
            //Atualiza o desenho do tanque com o valor do trackbar:

            int tx = tanque.Width;
            int ty = tanque.Height;

            Bitmap bmp = new Bitmap(tx, ty);
            Graphics gp = Graphics.FromImage(bmp);

            //float valor = trackBar1.Value;
            float val = 1.0f - ((float) (Globals.valorNivel/1023.0));
            

            float alt = (float)ty * val;

            gp.FillRectangle(Brushes.Blue, 0, alt, tx, ty - alt);
           
            tanque.Image = bmp;
        }

        //private void trackBar1_Scroll(object sender, EventArgs e)
        //{
        //    //Atualiza o textbox com o valor do trackbar:
        //    float valor = trackBar1.Value;
        //    textBox1.Text = valor.ToString("#0.0") + "%";
        //}

      

        private float ang = 0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            //Rotina do temporizador timer2... roda a cada 75ms
            //Atualiza o desenho do motor girando...

            int tx = motor.Width;
            int ty = motor.Height;

            Bitmap bmp = new Bitmap(tx, ty);
            Graphics gp = Graphics.FromImage(bmp);

            //passo de atualização da velocidade de giro:
            float StepAng = ((float)10 / 100) * 90;
            
            //executa o giro
            if (ang < 360)
                ang += StepAng;
            else
                ang = 0;

            //desenha o motor:
            gp.FillPie(Brushes.Blue, 0, 0, tx, ty, ang + 000, 040);
            gp.FillPie(Brushes.Red, 0, 0, tx, ty, ang + 040, 140);
            gp.FillPie(Brushes.Blue, 0, 0, tx, ty, ang + 180, 040);
            gp.FillPie(Brushes.Red, 0, 0, tx, ty, ang + 220, 140);

            motor.Image = bmp;
        }

        private void btn_ligar_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
                serialPort1.Write("L");
        }

    }
}

﻿namespace ExNivel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tanque = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.motor = new System.Windows.Forms.PictureBox();
            this.timer_motor = new System.Windows.Forms.Timer(this.components);
            this.lbValv = new System.Windows.Forms.Label();
            this.b3_02 = new System.Windows.Forms.Label();
            this.b3_01 = new System.Windows.Forms.Label();
            this.lbl_conn = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.btn_conn = new System.Windows.Forms.Button();
            this.timerLeitura = new System.Windows.Forms.Timer(this.components);
            this.cmb_conn = new System.Windows.Forms.ComboBox();
            this.btn_ligar = new System.Windows.Forms.Button();
            this.snb = new System.Windows.Forms.Label();
            this.sna = new System.Windows.Forms.Label();
            this.b1_02 = new System.Windows.Forms.Label();
            this.b1_01 = new System.Windows.Forms.Label();
            this.b1_img = new System.Windows.Forms.Label();
            this.b2_img = new System.Windows.Forms.Label();
            this.b2_02 = new System.Windows.Forms.Label();
            this.b2_01 = new System.Windows.Forms.Label();
            this.b3_img = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tanque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.motor)).BeginInit();
            this.SuspendLayout();
            // 
            // tanque
            // 
            this.tanque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tanque.Location = new System.Drawing.Point(166, 153);
            this.tanque.Name = "tanque";
            this.tanque.Size = new System.Drawing.Size(97, 226);
            this.tanque.TabIndex = 1;
            this.tanque.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // motor
            // 
            this.motor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.motor.Location = new System.Drawing.Point(184, 87);
            this.motor.Name = "motor";
            this.motor.Size = new System.Drawing.Size(60, 60);
            this.motor.TabIndex = 1;
            this.motor.TabStop = false;
            // 
            // timer_motor
            // 
            this.timer_motor.Interval = 75;
            this.timer_motor.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lbValv
            // 
            this.lbValv.Image = ((System.Drawing.Image)(resources.GetObject("lbValv.Image")));
            this.lbValv.Location = new System.Drawing.Point(296, 344);
            this.lbValv.Name = "lbValv";
            this.lbValv.Size = new System.Drawing.Size(21, 28);
            this.lbValv.TabIndex = 12;
            // 
            // b3_02
            // 
            this.b3_02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b3_02.Location = new System.Drawing.Point(262, 359);
            this.b3_02.Name = "b3_02";
            this.b3_02.Size = new System.Drawing.Size(35, 13);
            this.b3_02.TabIndex = 13;
            // 
            // b3_01
            // 
            this.b3_01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b3_01.Location = new System.Drawing.Point(316, 359);
            this.b3_01.Name = "b3_01";
            this.b3_01.Size = new System.Drawing.Size(35, 13);
            this.b3_01.TabIndex = 13;
            // 
            // lbl_conn
            // 
            this.lbl_conn.AutoSize = true;
            this.lbl_conn.Location = new System.Drawing.Point(9, 12);
            this.lbl_conn.Name = "lbl_conn";
            this.lbl_conn.Size = new System.Drawing.Size(87, 13);
            this.lbl_conn.TabIndex = 20;
            this.lbl_conn.Text = "Selecionar COM:";
            // 
            // btn_conn
            // 
            this.btn_conn.Location = new System.Drawing.Point(115, 27);
            this.btn_conn.Name = "btn_conn";
            this.btn_conn.Size = new System.Drawing.Size(127, 21);
            this.btn_conn.TabIndex = 18;
            this.btn_conn.Text = "Conectar";
            this.btn_conn.UseVisualStyleBackColor = true;
            // 
            // timerLeitura
            // 
            this.timerLeitura.Interval = 300;
            // 
            // cmb_conn
            // 
            this.cmb_conn.FormattingEnabled = true;
            this.cmb_conn.Location = new System.Drawing.Point(12, 28);
            this.cmb_conn.Name = "cmb_conn";
            this.cmb_conn.Size = new System.Drawing.Size(97, 21);
            this.cmb_conn.TabIndex = 19;
            // 
            // btn_ligar
            // 
            this.btn_ligar.Enabled = false;
            this.btn_ligar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ligar.Location = new System.Drawing.Point(464, 344);
            this.btn_ligar.Name = "btn_ligar";
            this.btn_ligar.Size = new System.Drawing.Size(75, 39);
            this.btn_ligar.TabIndex = 21;
            this.btn_ligar.Text = "Ligar";
            this.btn_ligar.UseVisualStyleBackColor = true;
            this.btn_ligar.Click += new System.EventHandler(this.btn_ligar_Click);
            // 
            // snb
            // 
            this.snb.BackColor = System.Drawing.Color.Black;
            this.snb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.snb.Location = new System.Drawing.Point(139, 323);
            this.snb.Name = "snb";
            this.snb.Size = new System.Drawing.Size(21, 10);
            this.snb.TabIndex = 22;
            // 
            // sna
            // 
            this.sna.BackColor = System.Drawing.Color.Black;
            this.sna.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sna.Location = new System.Drawing.Point(139, 246);
            this.sna.Name = "sna";
            this.sna.Size = new System.Drawing.Size(21, 10);
            this.sna.TabIndex = 22;
            // 
            // b1_02
            // 
            this.b1_02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1_02.Location = new System.Drawing.Point(132, 166);
            this.b1_02.Name = "b1_02";
            this.b1_02.Size = new System.Drawing.Size(35, 13);
            this.b1_02.TabIndex = 24;
            // 
            // b1_01
            // 
            this.b1_01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1_01.Location = new System.Drawing.Point(34, 202);
            this.b1_01.Name = "b1_01";
            this.b1_01.Size = new System.Drawing.Size(35, 13);
            this.b1_01.TabIndex = 25;
            // 
            // b1_img
            // 
            this.b1_img.Image = global::ExNivel.Properties.Resources.BMBD2_mi;
            this.b1_img.Location = new System.Drawing.Point(68, 161);
            this.b1_img.Name = "b1_img";
            this.b1_img.Size = new System.Drawing.Size(65, 67);
            this.b1_img.TabIndex = 26;
            // 
            // b2_img
            // 
            this.b2_img.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.b2_img.Image = global::ExNivel.Properties.Resources.BMBD2;
            this.b2_img.Location = new System.Drawing.Point(296, 161);
            this.b2_img.Name = "b2_img";
            this.b2_img.Size = new System.Drawing.Size(65, 67);
            this.b2_img.TabIndex = 29;
            // 
            // b2_02
            // 
            this.b2_02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b2_02.Location = new System.Drawing.Point(262, 166);
            this.b2_02.Name = "b2_02";
            this.b2_02.Size = new System.Drawing.Size(35, 13);
            this.b2_02.TabIndex = 27;
            // 
            // b2_01
            // 
            this.b2_01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b2_01.Location = new System.Drawing.Point(360, 202);
            this.b2_01.Name = "b2_01";
            this.b2_01.Size = new System.Drawing.Size(35, 13);
            this.b2_01.TabIndex = 28;
            // 
            // b3_img
            // 
            this.b3_img.Image = global::ExNivel.Properties.Resources.BMBD2_mi;
            this.b3_img.Location = new System.Drawing.Point(350, 318);
            this.b3_img.Name = "b3_img";
            this.b3_img.Size = new System.Drawing.Size(66, 67);
            this.b3_img.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(68, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 20);
            this.label12.TabIndex = 31;
            this.label12.Text = "B1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(330, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 20);
            this.label13.TabIndex = 31;
            this.label13.Text = "B2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(385, 298);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 20);
            this.label14.TabIndex = 31;
            this.label14.Text = "B3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(250, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 20);
            this.label15.TabIndex = 31;
            this.label15.Text = "M";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(88, 236);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 20);
            this.label16.TabIndex = 31;
            this.label16.Text = "SNA";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(88, 313);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 20);
            this.label17.TabIndex = 31;
            this.label17.Text = "SNB";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 396);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.b3_img);
            this.Controls.Add(this.b2_img);
            this.Controls.Add(this.b2_02);
            this.Controls.Add(this.b2_01);
            this.Controls.Add(this.b1_img);
            this.Controls.Add(this.b1_02);
            this.Controls.Add(this.b1_01);
            this.Controls.Add(this.sna);
            this.Controls.Add(this.motor);
            this.Controls.Add(this.snb);
            this.Controls.Add(this.btn_ligar);
            this.Controls.Add(this.lbl_conn);
            this.Controls.Add(this.btn_conn);
            this.Controls.Add(this.cmb_conn);
            this.Controls.Add(this.b3_01);
            this.Controls.Add(this.b3_02);
            this.Controls.Add(this.lbValv);
            this.Controls.Add(this.tanque);
            this.Name = "Form1";
            this.Text = "Tanque";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tanque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.motor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox tanque;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox motor;
        private System.Windows.Forms.Timer timer_motor;
        private System.Windows.Forms.Label lbValv;
        private System.Windows.Forms.Label b3_02;
        private System.Windows.Forms.Label b3_01;
        private System.Windows.Forms.Label lbl_conn;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button btn_conn;
        private System.Windows.Forms.Timer timerLeitura;
        private System.Windows.Forms.ComboBox cmb_conn;
        private System.Windows.Forms.Button btn_ligar;
        private System.Windows.Forms.Label snb;
        private System.Windows.Forms.Label sna;
        private System.Windows.Forms.Label b1_02;
        private System.Windows.Forms.Label b1_01;
        private System.Windows.Forms.Label b1_img;
        private System.Windows.Forms.Label b2_img;
        private System.Windows.Forms.Label b2_02;
        private System.Windows.Forms.Label b2_01;
        private System.Windows.Forms.Label b3_img;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Estufa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int aqueceouresfria = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Enabled = false;
                aqueceouresfria = 0; 
                LB_Estufa.Image = new Bitmap("estufaTOP1.bmp");
            }
            else
            {
                timer1.Enabled = true;
                aqueceouresfria = 1;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Enabled = false;
                aqueceouresfria = 0;
                LB_Estufa.Image = new Bitmap("estufaTOP1.bmp");
            }
            else
            {
                timer1.Enabled = true;
                aqueceouresfria = 2;
            }

        }
        int contador = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (aqueceouresfria == 1)
            {
                if (contador == 0) LB_Estufa.Image = new Bitmap("aquecon1.bmp");
                if (contador == 1) LB_Estufa.Image = new Bitmap("aquecon2.bmp");
                if (contador == 2) LB_Estufa.Image = new Bitmap("aquecon3.bmp");
                if (contador == 3)
                {
                    LB_Estufa.Image = new Bitmap("aquecon4.bmp");
                    contador = 0;
                }
                contador++;
            }
            if (aqueceouresfria == 2)
            {
                if (contador == 0) LB_Estufa.Image = new Bitmap("resfrion1.bmp");
                if (contador == 1) LB_Estufa.Image = new Bitmap("resfrion2.bmp");
                if (contador == 2) LB_Estufa.Image = new Bitmap("resfrion3.bmp");
                if (contador == 3)
                {
                    LB_Estufa.Image = new Bitmap("resfrion4.bmp");
                    contador = 0;
                }
                contador++;
            }
        }
    }
}

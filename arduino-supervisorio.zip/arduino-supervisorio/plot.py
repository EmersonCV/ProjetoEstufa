#!/usr/bin/env python3

import matplotlib.pyplot as plt
import csv
x1 = list()
x2 = list()
x3 = list()
for line in open('aq1.txt'):
   if line.strip():# line contains eol character(s)
       x1.append(float(line.replace('\n','')))

for line in open('aq2.txt'):
   if line.strip():# line contains eol character(s)
       x2.append(float(line.replace('\n','')))

for line in open('t3.txt'):
   if line.strip():# line contains eol character(s)
       x3.append(float(line.replace('\n','')))
#x3 =[t-1.5 if t>43 else t for t in x2]
#with open('t3.txt', 'w') as f:
#	for i in x3:
#		f.write("%s\n" % i)
		
plt.plot(x1, label='teste 1')
plt.plot(x2, label='teste 2')
plt.plot(x3, label='teste fix')
plt.xlabel('x')
plt.ylabel('temp')
plt.legend()
plt.show()

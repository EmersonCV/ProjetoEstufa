﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;  // necessário para ter acesso as portas
using System.Globalization;
using System.Timers;

namespace Estufa
{

    public partial class Form1 : Form
    {
          
        public static class Globals{
            public static int ligado = 0;
            public static float temperatura;
            public static float setpoint;
            public static int sp_led;
            public static int controle_led = 2;

            public static int pwm_aq;
            public static int pwm_ex;
            
            public static bool anim_aq;
            public static bool anim_ex;

            public static bool enviaw = true;
        }

        public Form1()
        {
            InitializeComponent();
            cmb_iluminacao.SelectedIndex = 2;
            cmb_conn.SelectedItem = 0;
            chart.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart.ChartAreas[0].AxisY.Title = "Temperatura (°C)";
            chart.ChartAreas[0].AxisY.TitleFont = new Font("Segoe UI", 8, FontStyle.Regular);
            chart.ChartAreas[0].AxisX.IsLabelAutoFit = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
           
            //Rotina para atualizar comboBox com as portas COMs:                                    
            foreach (string comStr in SerialPort.GetPortNames())
            {   //Adiciona todas as COM diponíveis na lista
                cmb_conn.Items.Add(comStr);
            }
            //Seleciona a primeira posição da lista
            if (cmb_conn.Items.Count > 0)
            {
                cmb_conn.SelectedIndex = 0;
            }
        }

        delegate void SetTempCallback(string temp_txt);

        private void SetTempText(string temp_txt)
        {
            
            if (this.lbl_temp_atual.InvokeRequired)
            {
                SetTempCallback d = new SetTempCallback(SetTempText);
                this.Invoke(d, new object[] { temp_txt });
            }
            else
            {
                this.lbl_temp_atual.Text = temp_txt;
            }
        }

        delegate void SetLigarCallback(string ligar_txt);

        private void SetLigarText(string ligar_txt)
        {

            if (this.btn_ligar.InvokeRequired)
            {
                SetLigarCallback d = new SetLigarCallback(SetLigarText);
                this.Invoke(d, new object[] { ligar_txt });
            }
            else
            {
                this.btn_ligar.Text = ligar_txt;
            }
        }

        delegate void SetTrackTextCallback(string ligar_txt);
        
        private void SetTrackText(string track_txt)
        {

            if (this.lbl_track.InvokeRequired)
            {
                SetTrackTextCallback d = new SetTrackTextCallback(SetTrackText);
                this.Invoke(d, new object[] { track_txt });
            }
            else
            {
                this.lbl_track.Text = track_txt;
            }
        }

        private void btn_conn_Click(object sender, EventArgs e)
        {
            //Verifica se a porta COM do Arduino foi selecionada:
            if (cmb_conn.SelectedIndex < 0)
            {
                MessageBox.Show("Adicionar/Selecionar uma COM!");
                return;
            }

            if (serialPort1.IsOpen == false)
            {   //Se a conexao serial estiver fechada... abre uma conexao com o Arduino:
                try
                {
                    serialPort1.PortName = cmb_conn.Items[cmb_conn.SelectedIndex].ToString();
                    serialPort1.Open();
                    timerLeitura.Enabled = true;
                    btn_ligar.Enabled = true;
                    cmb_conn.Enabled = false;
                    btn_conn.Text = "Desconectar";
                }
                catch (Exception ex)
                {   //Erro ao conectar com o Arduino:
                    MessageBox.Show(ex.Message);                    
                }
            }
            else
            {   //Se a conexao serial estiver aberta... fecha a conexao com o Arduino:
                try
                {
                    serialPort1.Write("D");
                    serialPort1.Close();
                    timerLeitura.Enabled = false;
                    btn_ligar.Enabled = false;
                    cmb_conn.Enabled = true;
                    
                    Globals.anim_ex = false;
                    Globals.anim_aq = false;
                    lbl_aq.Image = global::Estufa.Properties.Resources.aq0;
                    btn_conn.Text = "Conectar";
                }
                catch (Exception ex)
                {   //Erro ao fechar a conexao com Arduino:
                    MessageBox.Show(ex.Message);                   
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {   //Se a conexao serial estiver aberta... fecha a conexao com o Arduino:
            if (serialPort1.IsOpen == true)
                serialPort1.Write("D");
                serialPort1.Close();
        }

        private void timerLeitura_Tick(object sender, EventArgs e)
        {   //Envia um comando para o Arduino enviar os dados monitorados...
            if (serialPort1.IsOpen == true && Globals.enviaw)
            {
                serialPort1.Write("W");
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {   //receber valor pela serial...
            string RxStr = serialPort1.ReadLine();  //le o dado disponível na serial                                                           
            RxStr = RxStr.Replace("\r", "");        //retirar codigo de nova linha...            

            string[] valores = RxStr.Split('#');    //divide a string pelo #
            // ligado # temp # ldr1 # ldr2 # aq # ex #

            Globals.ligado = int.Parse(valores[0]);
            Globals.temperatura = float.Parse(valores[1], CultureInfo.InvariantCulture);
            Globals.pwm_aq = int.Parse(valores[4]);
            Globals.pwm_ex = int.Parse(valores[5]);

            if (Globals.ligado == 1)
            {
                SetLigarText("Desligar");
            }
            else
            {
                SetLigarText("Ligar");
            }


            SetTempText(Globals.temperatura.ToString("#0.0") + "°C");

            if (Globals.pwm_aq == 1 && (Globals.ligado==1)) //valor pode ser ajustado
            {
                Globals.anim_aq = true;
                
            }
            else
            {
                Globals.anim_aq = false;
                lbl_aq.Image = global::Estufa.Properties.Resources.aq0;
            }

            if (Globals.pwm_ex == 1 && (Globals.ligado == 1)) //valor pode ser ajustado
            {
                Globals.anim_ex = true;
                
            }
            else
            {
                Globals.anim_ex = false;
                lbl_ex.Image = global::Estufa.Properties.Resources.re1;
            }


            
        }
        private void btn_ligar_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                if (btn_ligar.Text == "Ligar")
                {
                    serialPort1.Write("L");
                    btn_ligar.Text = "Desligar";
                }
                else if (btn_ligar.Text == "Desligar")
                {
                    serialPort1.Write("D");
                    Globals.anim_ex = false;
                    Globals.anim_aq = false;
                    lbl_aq.Image = global::Estufa.Properties.Resources.aq0;
                    btn_ligar.Text = "Ligar";
                }
            }
                
        }

        private void cmb_iluminacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            Globals.controle_led = cmb_iluminacao.SelectedIndex;
            //MessageBox.Show(Globals.controle_led.ToString());
            if (serialPort1.IsOpen == true)
            {

                Globals.enviaw = false;
                serialPort1.Write("I");
                serialPort1.Write(Globals.controle_led.ToString());
                Globals.enviaw = true;
                
            }
        }

        private void ud_sp_ValueChanged(object sender, EventArgs e)
        {
            Globals.setpoint = (float) ud_sp.Value;
            if (serialPort1.IsOpen == true)
            {

                Globals.enviaw = false;
                serialPort1.Write("S");
                serialPort1.Write(Globals.setpoint.ToString());
                Globals.enviaw = true;
                
            }
        }

        
        
        
        int cont_aq = 0;
        private void timerAnimAq_Tick(object sender, EventArgs e)
        {
            if (Globals.anim_aq)
            {
                if (cont_aq == 0) lbl_aq.Image = global::Estufa.Properties.Resources.aq1;
                if (cont_aq == 1) lbl_aq.Image = global::Estufa.Properties.Resources.aq2;
                if (cont_aq == 2) lbl_aq.Image = global::Estufa.Properties.Resources.aq3;
                if (cont_aq == 3)
                {
                    lbl_aq.Image = global::Estufa.Properties.Resources.aq4;
                    cont_aq = 0;
                }
                cont_aq++;
            }
        }

        int cont_ex = 0;       
        private void timerAnimEx_Tick(object sender, EventArgs e)
         {

             if (Globals.anim_ex)
             {
                 if (cont_ex == 0) lbl_ex.Image = global::Estufa.Properties.Resources.re1;
                 if (cont_ex == 1) lbl_ex.Image = global::Estufa.Properties.Resources.re2;
                 if (cont_ex == 2) lbl_ex.Image = global::Estufa.Properties.Resources.re3;
                 if (cont_ex == 3)
                 {
                     lbl_ex.Image = global::Estufa.Properties.Resources.re4;
                     cont_ex = 0;
                 }
                 cont_ex++;
             }
        }

        private void timerGraf_Tick(object sender, EventArgs e)
        {

            DateTime timeValue = DateTime.Now; // for example

           
                chart.Series[0].Points.AddXY(timeValue, Globals.temperatura);
                //chart.Series[1].Points.AddXY(timeValue, Globals.setpoint);
           

        }

        private void track_led_Scroll(object sender, EventArgs e)
        {
            Globals.sp_led = 1023 - track_led.Value;
            
            float valor_pc = (((float) track_led.Value/1023)*100);

            SetTrackText(valor_pc.ToString("#0.0") + "%");
            
            
            if (serialPort1.IsOpen == true)
            {

                Globals.enviaw = false;
                serialPort1.Write("J");
                serialPort1.Write(Globals.sp_led.ToString());
                Globals.enviaw = true;

            }
        }


      

    }
}

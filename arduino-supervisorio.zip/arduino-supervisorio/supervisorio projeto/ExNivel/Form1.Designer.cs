﻿namespace Estufa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.lbl_conn = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.btn_conn = new System.Windows.Forms.Button();
            this.timerLeitura = new System.Windows.Forms.Timer(this.components);
            this.cmb_conn = new System.Windows.Forms.ComboBox();
            this.btn_ligar = new System.Windows.Forms.Button();
            this.lbl_iluminacao = new System.Windows.Forms.Label();
            this.cmb_iluminacao = new System.Windows.Forms.ComboBox();
            this.lbl_sp = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ud_sp = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_temp_atual = new System.Windows.Forms.Label();
            this.timerAnimAq = new System.Windows.Forms.Timer(this.components);
            this.timerAnimEx = new System.Windows.Forms.Timer(this.components);
            this.lbl_ex = new System.Windows.Forms.Label();
            this.lbl_aq = new System.Windows.Forms.Label();
            this.timerGraf = new System.Windows.Forms.Timer(this.components);
            this.chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.track_led = new System.Windows.Forms.TrackBar();
            this.lbl_track = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ud_sp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_led)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_conn
            // 
            this.lbl_conn.AutoSize = true;
            this.lbl_conn.Location = new System.Drawing.Point(9, 12);
            this.lbl_conn.Name = "lbl_conn";
            this.lbl_conn.Size = new System.Drawing.Size(62, 13);
            this.lbl_conn.TabIndex = 20;
            this.lbl_conn.Text = "Porta COM:";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // btn_conn
            // 
            this.btn_conn.Location = new System.Drawing.Point(183, 9);
            this.btn_conn.Name = "btn_conn";
            this.btn_conn.Size = new System.Drawing.Size(77, 22);
            this.btn_conn.TabIndex = 18;
            this.btn_conn.Text = "Conectar";
            this.btn_conn.UseVisualStyleBackColor = true;
            this.btn_conn.Click += new System.EventHandler(this.btn_conn_Click);
            // 
            // timerLeitura
            // 
            this.timerLeitura.Interval = 300;
            this.timerLeitura.Tick += new System.EventHandler(this.timerLeitura_Tick);
            // 
            // cmb_conn
            // 
            this.cmb_conn.FormattingEnabled = true;
            this.cmb_conn.Location = new System.Drawing.Point(80, 9);
            this.cmb_conn.Name = "cmb_conn";
            this.cmb_conn.Size = new System.Drawing.Size(97, 21);
            this.cmb_conn.TabIndex = 19;
            // 
            // btn_ligar
            // 
            this.btn_ligar.Enabled = false;
            this.btn_ligar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ligar.Location = new System.Drawing.Point(640, 282);
            this.btn_ligar.Name = "btn_ligar";
            this.btn_ligar.Size = new System.Drawing.Size(96, 39);
            this.btn_ligar.TabIndex = 21;
            this.btn_ligar.Text = "Ligar";
            this.btn_ligar.UseVisualStyleBackColor = true;
            this.btn_ligar.Click += new System.EventHandler(this.btn_ligar_Click);
            // 
            // lbl_iluminacao
            // 
            this.lbl_iluminacao.AutoSize = true;
            this.lbl_iluminacao.Location = new System.Drawing.Point(619, 5);
            this.lbl_iluminacao.Name = "lbl_iluminacao";
            this.lbl_iluminacao.Size = new System.Drawing.Size(117, 13);
            this.lbl_iluminacao.TabIndex = 22;
            this.lbl_iluminacao.Text = "Controle da iluminação:";
            // 
            // cmb_iluminacao
            // 
            this.cmb_iluminacao.FormattingEnabled = true;
            this.cmb_iluminacao.Items.AddRange(new object[] {
            "Ligado",
            "Desligado",
            "Setpoint"});
            this.cmb_iluminacao.Location = new System.Drawing.Point(622, 21);
            this.cmb_iluminacao.Name = "cmb_iluminacao";
            this.cmb_iluminacao.Size = new System.Drawing.Size(114, 21);
            this.cmb_iluminacao.TabIndex = 23;
            this.cmb_iluminacao.SelectedIndexChanged += new System.EventHandler(this.cmb_iluminacao_SelectedIndexChanged);
            // 
            // lbl_sp
            // 
            this.lbl_sp.AutoSize = true;
            this.lbl_sp.Location = new System.Drawing.Point(619, 153);
            this.lbl_sp.Name = "lbl_sp";
            this.lbl_sp.Size = new System.Drawing.Size(116, 13);
            this.lbl_sp.TabIndex = 22;
            this.lbl_sp.Text = "Temperatura desejada:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(711, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 18);
            this.label1.TabIndex = 25;
            this.label1.Text = "°C";
            // 
            // ud_sp
            // 
            this.ud_sp.DecimalPlaces = 1;
            this.ud_sp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ud_sp.Location = new System.Drawing.Point(652, 173);
            this.ud_sp.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ud_sp.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.ud_sp.Name = "ud_sp";
            this.ud_sp.Size = new System.Drawing.Size(59, 24);
            this.ud_sp.TabIndex = 26;
            this.ud_sp.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.ud_sp.ValueChanged += new System.EventHandler(this.ud_sp_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(637, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Temperatura atual:";
            // 
            // lbl_temp_atual
            // 
            this.lbl_temp_atual.AutoSize = true;
            this.lbl_temp_atual.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_temp_atual.Location = new System.Drawing.Point(646, 226);
            this.lbl_temp_atual.Name = "lbl_temp_atual";
            this.lbl_temp_atual.Size = new System.Drawing.Size(49, 32);
            this.lbl_temp_atual.TabIndex = 22;
            this.lbl_temp_atual.Text = "-°C";
            this.lbl_temp_atual.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timerAnimAq
            // 
            this.timerAnimAq.Enabled = true;
            this.timerAnimAq.Tick += new System.EventHandler(this.timerAnimAq_Tick);
            // 
            // timerAnimEx
            // 
            this.timerAnimEx.Enabled = true;
            this.timerAnimEx.Tick += new System.EventHandler(this.timerAnimEx_Tick);
            // 
            // lbl_ex
            // 
            this.lbl_ex.Image = ((System.Drawing.Image)(resources.GetObject("lbl_ex.Image")));
            this.lbl_ex.Location = new System.Drawing.Point(21, 47);
            this.lbl_ex.Name = "lbl_ex";
            this.lbl_ex.Size = new System.Drawing.Size(124, 264);
            this.lbl_ex.TabIndex = 28;
            // 
            // lbl_aq
            // 
            this.lbl_aq.Image = ((System.Drawing.Image)(resources.GetObject("lbl_aq.Image")));
            this.lbl_aq.Location = new System.Drawing.Point(145, 50);
            this.lbl_aq.Name = "lbl_aq";
            this.lbl_aq.Size = new System.Drawing.Size(124, 259);
            this.lbl_aq.TabIndex = 27;
            // 
            // timerGraf
            // 
            this.timerGraf.Enabled = true;
            this.timerGraf.Interval = 1000;
            this.timerGraf.Tick += new System.EventHandler(this.timerGraf_Tick);
            // 
            // chart
            // 
            this.chart.BackColor = System.Drawing.SystemColors.Control;
            chartArea5.Name = "ChartArea1";
            this.chart.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart.Legends.Add(legend5);
            this.chart.Location = new System.Drawing.Point(275, 21);
            this.chart.Name = "chart";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series9.IsVisibleInLegend = false;
            series9.Legend = "Legend1";
            series9.Name = "Series1";
            series9.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series10.IsVisibleInLegend = false;
            series10.Legend = "Legend1";
            series10.Name = "Series2";
            this.chart.Series.Add(series9);
            this.chart.Series.Add(series10);
            this.chart.Size = new System.Drawing.Size(341, 300);
            this.chart.TabIndex = 29;
            this.chart.Text = "chart1";
            // 
            // track_led
            // 
            this.track_led.Location = new System.Drawing.Point(622, 47);
            this.track_led.Maximum = 1023;
            this.track_led.Name = "track_led";
            this.track_led.Size = new System.Drawing.Size(114, 45);
            this.track_led.TabIndex = 30;
            this.track_led.TickStyle = System.Windows.Forms.TickStyle.None;
            this.track_led.Scroll += new System.EventHandler(this.track_led_Scroll);
            // 
            // lbl_track
            // 
            this.lbl_track.AutoSize = true;
            this.lbl_track.Location = new System.Drawing.Point(622, 79);
            this.lbl_track.Name = "lbl_track";
            this.lbl_track.Size = new System.Drawing.Size(21, 13);
            this.lbl_track.TabIndex = 31;
            this.lbl_track.Text = "0%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 333);
            this.Controls.Add(this.lbl_track);
            this.Controls.Add(this.track_led);
            this.Controls.Add(this.chart);
            this.Controls.Add(this.lbl_ex);
            this.Controls.Add(this.lbl_aq);
            this.Controls.Add(this.ud_sp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_temp_atual);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_sp);
            this.Controls.Add(this.cmb_iluminacao);
            this.Controls.Add(this.lbl_iluminacao);
            this.Controls.Add(this.btn_ligar);
            this.Controls.Add(this.lbl_conn);
            this.Controls.Add(this.btn_conn);
            this.Controls.Add(this.cmb_conn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Supervisório Estufa";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ud_sp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_led)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_conn;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button btn_conn;
        private System.Windows.Forms.Timer timerLeitura;
        private System.Windows.Forms.ComboBox cmb_conn;
        private System.Windows.Forms.Button btn_ligar;
        private System.Windows.Forms.Label lbl_iluminacao;
        private System.Windows.Forms.ComboBox cmb_iluminacao;
        private System.Windows.Forms.Label lbl_sp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown ud_sp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_temp_atual;
        private System.Windows.Forms.Timer timerAnimAq;
        private System.Windows.Forms.Label lbl_aq;
        private System.Windows.Forms.Label lbl_ex;
        private System.Windows.Forms.Timer timerGraf;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart;
        private System.Windows.Forms.Timer timerAnimEx;
        private System.Windows.Forms.TrackBar track_led;
        private System.Windows.Forms.Label lbl_track;
    }
}

